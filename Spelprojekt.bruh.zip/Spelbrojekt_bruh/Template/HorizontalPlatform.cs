﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Template
{
    class HorizontalPlatform : Platform
    {
        bool movingLeft = true;

        Vector2 startingPos;
        public HorizontalPlatform(Texture2D texture) : base(texture)
        {
            startingPos = Position;
        }

        public override void Update()
        {
            if(Position.X < startingPos.X - 50)
            {
                movingLeft = false;
            }
            else if (Position.X > startingPos.X + 50)
            {
                movingLeft = true;
            }

            if (movingLeft)
            {
                Velocity = new Vector2(-2, 0);
            }
            else
            {
                Velocity = new Vector2(2, 0);
            }

        }

    }

}
